package com.example.autounfollow

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.LinearLayout
import android.widget.TextView
import java.text.Normalizer
import kotlin.math.abs
import kotlin.random.Random

class UnfollowService : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private var panel: LinearLayout? = null
    private var icon: TextView? = null
    private var countTv: TextView? = null
    private var statusTv: TextView? = null
    private var running = false
    private var count = 0
    private var scrollFails = 0
    private val tapCount = HashMap<String, Int>()

    private val followingLabels = setOf("following", "फॉलोइंग", "फॉलो किया गया", "फॉलो किया जा रहा है", "फॉलो कर रहे हैं")
    private val unfollowLabels = setOf("unfollow", "अनफॉलो", "अनफॉलो करें")
    private val messageLabels = setOf("message", "मैसेज", "मैसेज भेजें", "संदेश", "संदेश भेजें")
    private val dotsLabels = setOf("more", "more options", "options", "more actions", "menu", "और", "अधिक", "और विकल्प", "विकल्प")

    private var pending = false      // ek unfollow process chal raha hai (count ke liye)
    private var awaitSheet = false   // 3-dot menu khulne ka wait
    private var awaitSince = 0L
    private var sinceScroll = 0      // pichhle scroll ke baad kitne unfollow hue
    private var lastSig = 0          // screen ke text ka signature (list khatam pehchanne ke liye)
    private val batch = 5            // itne unfollow ke baad turant scroll

    // ---- auto navigation (Instagram -> Profile -> Following) ----
    private var lost = 0             // lagatar kitni baar "Following list" screen nahi dikhi
    private var navStep = 0          // recovery steps (profile tab tap / back alternate)
    private var navUntil = 0L        // is time tak naya navigation action mat karo
    private var wasList = false      // pichhle step me Following list thi
    private var lastLaunch = 0L      // Instagram aakhri baar kab khola
    private val postsRe = Regex("^([\\d.,]+\\s*[kmb]?\\s*)?(posts?|पोस्ट)$")
    private val followersRe = Regex("^[\\d.,]+\\s*[kmb]?\\s*(followers?|फॉलोअर्स?)$")
    private val followingRe = Regex("^[\\d.,]+\\s*[kmb]?\\s*(following|फॉलोइंग)$")
    private val editLabels = setOf("edit profile", "प्रोफाइल संपादित करें")
    private val bottomTabs = setOf("home", "reels", "messages", "search", "search and explore", "profile")

    companion object {
        @Volatile var instance: UnfollowService? = null
    }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "overlay") { if (prefs.getBoolean("overlay", false)) showPanel() else hidePanel() }
        if (key == "go" && panel != null) startRun()
    }

    private val tick = object : Runnable {
        override fun run() {
            var next = 500L
            if (running) {
                next = try { step() } catch (e: Exception) { setStatus("error: " + e.javaClass.simpleName); 2000L }
            }
            h.postDelayed(this, next)
        }
    }

    // speed: 0 = slow, 1 = normal, 2 = fast (MainActivity me set hota hai)
    private fun pause(base: Long): Long {
        val mul = when (prefs.getInt("speed", 1)) { 0 -> 1.1; 2 -> 0.35; else -> 0.65 }
        return ((base + Random.nextLong(0, base / 2 + 1)) * mul).toLong()
    }

    override fun onServiceConnected() {
        instance = this
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        if (prefs.getBoolean("overlay", false)) showPanel()
        h.removeCallbacks(tick); h.post(tick)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean { instance = null; hidePanel(); return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; h.removeCallbacks(tick); hidePanel(); super.onDestroy() }

    // ---------- main logic ----------
    private fun norm(s: CharSequence?): String =
        Normalizer.normalize((s ?: "").toString(), Normalizer.Form.NFD).replace("\u093C", "").trim().lowercase()

    private fun labelOf(n: AccessibilityNodeInfo): String {
        val t = n.text
        return if (!t.isNullOrEmpty()) norm(t) else norm(n.contentDescription)
    }

    private fun walk(n: AccessibilityNodeInfo?, f: (AccessibilityNodeInfo) -> Unit) {
        if (n == null) return
        f(n)
        for (i in 0 until n.childCount) walk(n.getChild(i), f)
    }

    private fun panelRect(): Rect? {
        val p = panel ?: return null
        val loc = IntArray(2); p.getLocationOnScreen(loc)
        val pad = (8 * resources.displayMetrics.density).toInt()
        return Rect(loc[0] - pad, loc[1] - pad, loc[0] + p.width + pad, loc[1] + p.height + pad)
    }

    private fun step(): Long {
        val root = rootInActiveWindow
        val now = System.currentTimeMillis()
        if (root == null || root.packageName?.toString() != "com.instagram.android") {
            // Instagram se bahar nikal gaye (back/home) -> wapas Instagram khol do
            wasList = false
            if (now - lastLaunch > 4000L) { lastLaunch = now; launchInstagram(); setStatus("Instagram khol raha hu…") }
            else setStatus("Instagram kholo")
            return 1500L
        }
        val dm = resources.displayMetrics
        val sw = dm.widthPixels
        val sh = dm.heightPixels
        val rb = Rect(); root.getBoundsInScreen(rb)
        var hasPosts = false; var hasEdit = false
        var followersTab = false; var followingTab = false
        var followingStat: AccessibilityNodeInfo? = null
        var statLabel: AccessibilityNodeInfo? = null
        var profileTab: AccessibilityNodeInfo? = null
        var tabBar = false
        var confirm: AccessibilityNodeInfo? = null
        var sig = 17
        val buttons = ArrayList<AccessibilityNodeInfo>()   // "Message" / "Following" buttons (har row ka)
        val dots = ArrayList<AccessibilityNodeInfo>()      // 3-dot (⋮) buttons
        val r = Rect()
        walk(root) { n ->
            val l = labelOf(n)
            n.getBoundsInScreen(r)
            val id = n.viewIdResourceName ?: ""
            if (id.endsWith("profile_tab")) profileTab = n
            if (id.endsWith("row_profile_header_following_container")) followingStat = n
            if (l.isNotEmpty()) {
                if (postsRe.matches(l)) hasPosts = true
                if (l in editLabels) hasEdit = true
                if (r.top < sh * 0.25) {
                    if (followersRe.matches(l)) followersTab = true
                    if (followingRe.matches(l)) { followingTab = true; if (followingStat == null) followingStat = n }
                }
                if (followingStat == null && l in followingLabels && r.top > sh * 0.1 && r.top < sh * 0.3) statLabel = n
                if (r.top > rb.bottom - sh * 0.12 && l in bottomTabs) {
                    tabBar = true
                    if (l == "profile" && profileTab == null) profileTab = n
                }
            }
            if (l in unfollowLabels) {
                val cur = confirm
                if (cur == null || (!cur.isClickable && n.isClickable)) confirm = n
            } else if (l in followingLabels || l in messageLabels) {
                if (r.top > sh * 0.18 && r.centerX() > sw * 0.4 && r.centerX() < sw * 0.9) buttons.add(n)
            } else if (l in dotsLabels) {
                if (r.top > sh * 0.18 && r.bottom < sh * 0.97 && r.centerX() > sw * 0.8) dots.add(n)
            }
            val tx = n.text; if (!tx.isNullOrEmpty()) sig = sig * 31 + tx.toString().hashCode()
        }
        val rowKeys = HashSet<Int>()
        for (b in buttons) { b.getBoundsInScreen(r); rowKeys.add(r.centerY() / (sh / 25)) }
        val looksLikeList = rowKeys.size >= 2 || dots.isNotEmpty()
        val isProfile = hasEdit
        // Following list tabhi maanenge jab upar "followers | following" tabs hon aur profile/posts na ho
        val inList = !hasPosts && !hasEdit &&
            ((followersTab && followingTab) || (wasList && rowKeys.size >= 2 && dots.isNotEmpty()))

        // 1) Unfollow option / confirm (3-dot menu ya dialog me) — sirf list ke session me
        val c = confirm
        if (c != null && (wasList || pending)) {
            tap(c)
            if (pending) {
                count++; sinceScroll++; pending = false
                prefs.edit().putInt("total", prefs.getInt("total", 0) + 1).apply()
            }
            awaitSheet = false; tapCount.clear(); scrollFails = 0
            setStatus("Unfollow ✔"); return pause(1000L)
        }

        // 2) 3-dot menu abhi khul raha hai — thoda ruko
        if (awaitSheet) {
            if (now - awaitSince < 3500L) { setStatus("Menu wait…"); return pause(400L) }
            awaitSheet = false; pending = false
        }

        // 2.2) Sahi screen (Following list) par nahi ho -> khud Instagram > Profile > Following tak jao
        if (!inList) {
            if (++lost < 2) { setStatus("Screen check…"); return 600L }
            wasList = false
            return navigate(now, rb, sw, sh, isProfile, followingStat ?: statLabel, profileTab, tabBar)
        }
        lost = 0
        if (!wasList) { wasList = true; navStep = 0; setStatus("Following list ✔"); return pause(1200L) }

        // 2.5) 5 unfollow ho gaye -> turant scroll
        if (sinceScroll >= batch) return doScroll(sw, sh, sig)

        // 3) Jis row me abhi bhi "Message"/"Following" hai wahi follow hai -> uska ⋮ dabao
        if (looksLikeList) {
            buttons.sortBy { n -> val t = Rect(); n.getBoundsInScreen(t); t.top }
            val panelR = panelRect()
            for (b in buttons) {
                b.getBoundsInScreen(r)
                val k = r.flattenToString()
                val t = tapCount[k] ?: 0
                val cy = r.centerY()
                if (labelOf(b) in followingLabels) {
                    // purana tareeka: seedha Following button
                    if (t < 3) {
                        tapCount[k] = t + 1; tap(b)
                        pending = true; awaitSheet = true; awaitSince = now
                        setStatus("Button dabaya"); return pause(700L)
                    }
                    continue
                }
                if (t >= 2) continue
                // is row ka 3-dot button
                var dn: AccessibilityNodeInfo? = null
                var dd = Int.MAX_VALUE
                val tmp = Rect()
                for (d in dots) {
                    d.getBoundsInScreen(tmp)
                    val diff = abs(tmp.centerY() - cy)
                    if (diff < sh * 0.04 && diff < dd) { dd = diff; dn = d }
                }
                if (dn != null) {
                    tapCount[k] = t + 1; tap(dn)
                } else {
                    val x = sw * 0.945f
                    if (panelR != null && panelR.contains(x.toInt(), cy)) continue   // popup ke neeche hai
                    tapCount[k] = t + 1
                    gesture(x, cy.toFloat(), x, cy.toFloat(), 60)
                }
                pending = true; awaitSheet = true; awaitSince = now
                setStatus("⋮ dabaya"); return pause(700L)
            }
        }

        // 4) Koi row bachi nahi -> scroll
        return doScroll(sw, sh, sig)
    }

    private fun doScroll(sw: Int, sh: Int, sig: Int): Long {
        // pichhli baar scroll ke baad screen same hai -> list khatam ho rahi hai
        if (sig == lastSig) { if (++scrollFails >= 3) { toggle(); setStatus("List khatam ✔"); return 1000L } } else scrollFails = 0
        lastSig = sig
        var x = sw * 0.62f
        val pr = panelRect()
        if (pr != null && pr.contains(x.toInt(), (sh * 0.6f).toInt())) x = sw * 0.3f
        gesture(x, sh * 0.78f, x, sh * 0.36f, 450)
        tapCount.clear(); sinceScroll = 0
        setStatus("Scroll ↓")
        return pause(1300L)
    }

    private fun tap(node: AccessibilityNodeInfo) {
        var n: AccessibilityNodeInfo? = node
        while (n != null && !n.isClickable) n = n.parent
        if (n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return
        val r = Rect(); node.getBoundsInScreen(r)
        gesture(r.centerX().toFloat(), r.centerY().toFloat(), r.centerX().toFloat(), r.centerY().toFloat(), 60)
    }

    private fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long) {
        val p = Path(); p.moveTo(x1, y1)
        if (x1 != x2 || y1 != y2) p.lineTo(x2, y2)
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build(), null, null)
    }

    // ---------- floating popup ----------
    private fun navigate(now: Long, rb: Rect, sw: Int, sh: Int, isProfile: Boolean,
                         followingBtn: AccessibilityNodeInfo?, profileTab: AccessibilityNodeInfo?, tabBar: Boolean): Long {
        if (now < navUntil) { setStatus("Wait…"); return 500L }
        // Profile page par ho -> "Following" dabao
        if (isProfile && followingBtn != null) {
            tap(followingBtn); navUntil = now + 2200L
            setStatus("Following khola"); return 800L
        }
        // Warna: ek baar Profile tab dabao, na chale to Back — aise alternate
        navStep++
        if (navStep % 2 == 1 && (profileTab != null || tabBar)) {
            if (profileTab != null) tap(profileTab)
            else { val y = rb.bottom - sh * 0.03f; gesture(sw * 0.9f, y, sw * 0.9f, y, 60) }
            navUntil = now + 1800L
            setStatus("Profile khola"); return 800L
        }
        performGlobalAction(GLOBAL_ACTION_BACK)
        navUntil = now + 1200L
        setStatus("Back ↩"); return 800L
    }

    private fun launchInstagram() {
        val i = packageManager.getLaunchIntentForPackage("com.instagram.android") ?: return
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try { startActivity(i) } catch (_: Exception) {}
    }

    private fun resetState() {
        scrollFails = 0; pending = false; awaitSheet = false; tapCount.clear(); sinceScroll = 0; lastSig = 0
        lost = 0; navStep = 0; navUntil = 0L; wasList = false; lastLaunch = 0L
    }

    // MainActivity ke START se: seedha chalu (Instagram > Profile > Following > Unfollow)
    private fun startRun() {
        resetState(); count = 0; running = true; lastLaunch = System.currentTimeMillis()
        h.removeCallbacks(tick); h.post(tick)
        icon?.text = "⏸"; setStatus("Chal raha hai…")
    }

    private fun toggle() {
        running = !running; resetState()
        if (running) { h.removeCallbacks(tick); h.post(tick) }
        icon?.text = if (running) "⏸" else "▶"
        setStatus(if (running) "Chal raha hai…" else "Pause")
    }

    private fun setStatus(s: String) { statusTv?.text = s; countTv?.text = "$count unfollow" }

    private fun showPanel() {
        if (panel != null) return
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#8E2DE2"), Color.parseColor("#F5576C"), Color.parseColor("#FFA630"))
            ).apply { cornerRadius = dp(22).toFloat() }
        }
        icon = TextView(this).apply { text = "▶"; textSize = 36f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        countTv = TextView(this).apply { text = "0 unfollow"; textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setTypeface(null, android.graphics.Typeface.BOLD) }
        statusTv = TextView(this).apply { text = "Pause"; textSize = 11f; setTextColor(Color.parseColor("#FFF1E0")); gravity = Gravity.CENTER }
        p.addView(icon); p.addView(countTv); p.addView(statusTv)

        val lp = WindowManager.LayoutParams(
            dp(120), dp(120), WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(16); lp.y = dp(220)

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        p.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) { lp.x = ox + dx; lp.y = oy + dy; wm.updateViewLayout(p, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) toggle()
            }
            true
        }
        wm.addView(p, lp)
        panel = p
        running = false
    }

    private fun hidePanel() {
        panel?.let { try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {} }
        panel = null; running = false
    }
}
