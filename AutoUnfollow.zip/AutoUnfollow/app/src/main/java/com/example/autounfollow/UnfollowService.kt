package com.example.autounfollow

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class UnfollowService : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())
    private var scrollFails = 0

    private val tick = object : Runnable {
        override fun run() {
            try { step() } catch (_: Exception) {}
            h.postDelayed(this, Random.nextLong(4000, 9000)) // random delay
        }
    }

    override fun onServiceConnected() { h.post(tick) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { h.removeCallbacks(tick); super.onDestroy() }

    private fun step() {
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        if (!p.getBoolean("running", false)) return
        val today = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        if (p.getString("day", "") != today) p.edit().putString("day", today).putInt("count", 0).apply()
        val count = p.getInt("count", 0)
        if (count >= p.getInt("limit", 60)) { stop(p); return }

        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != "com.instagram.android") return

        // 1) Confirm dialog / bottom sheet: "Unfollow"
        val confirm = root.findAccessibilityNodeInfosByText("Unfollow")
            .firstOrNull { it.text?.toString().equals("Unfollow", true) }
        if (confirm != null) {
            click(confirm)
            p.edit().putInt("count", count + 1).apply()
            scrollFails = 0
            return
        }
        // 2) "Following" button in list row
        val btn = root.findAccessibilityNodeInfosByText("Following")
            .firstOrNull { it.text?.toString() == "Following" }
        if (btn != null) { click(btn); return }

        // 3) Nothing left on screen -> scroll
        val sc = findScrollable(root)
        if (sc != null && sc.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) scrollFails = 0
        else if (++scrollFails >= 3) stop(p)
    }

    private fun stop(p: android.content.SharedPreferences) { p.edit().putBoolean("running", false).apply() }

    private fun click(node: AccessibilityNodeInfo) {
        var n: AccessibilityNodeInfo? = node
        while (n != null && !n.isClickable) n = n.parent
        n?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun findScrollable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) n.getChild(i)?.let { c -> findScrollable(c)?.let { return it } }
        return null
    }
}
