package com.example.autounfollow

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.LinearLayout
import android.widget.TextView
import java.text.Normalizer
import kotlin.math.abs
import kotlin.random.Random

class UnfollowService : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private var panel: LinearLayout? = null
    private var icon: TextView? = null
    private var countTv: TextView? = null
    private var statusTv: TextView? = null
    private var running = false
    private var count = 0
    private var scrollFails = 0
    private val tapCount = HashMap<String, Int>()

    private val followingLabels = setOf("following", "फॉलोइंग", "फॉलो किया गया", "फॉलो किया जा रहा है", "फॉलो कर रहे हैं")
    private val unfollowLabels = setOf("unfollow", "अनफॉलो", "अनफॉलो करें")
    private val messageLabels = setOf("message", "मैसेज", "मैसेज भेजें", "संदेश", "संदेश भेजें")
    private val dotsLabels = setOf("more", "more options", "options", "more actions", "menu", "और", "अधिक", "और विकल्प", "विकल्प")

    private var pending = false      // ek unfollow process chal raha hai (count ke liye)
    private var awaitSheet = false   // 3-dot menu khulne ka wait
    private var awaitSince = 0L

    companion object {
        @Volatile var instance: UnfollowService? = null
    }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "overlay") { if (prefs.getBoolean("overlay", false)) showPanel() else hidePanel() }
    }

    private val tick = object : Runnable {
        override fun run() {
            var next = 500L
            if (running) {
                next = try { step() } catch (e: Exception) { setStatus("error: " + e.javaClass.simpleName); 2000L }
            }
            h.postDelayed(this, next)
        }
    }

    // speed: 0 = slow, 1 = normal, 2 = fast (MainActivity me set hota hai)
    private fun pause(base: Long): Long {
        val mul = when (prefs.getInt("speed", 1)) { 0 -> 1.6; 2 -> 0.6; else -> 1.0 }
        return ((base + Random.nextLong(0, base / 2 + 1)) * mul).toLong()
    }

    override fun onServiceConnected() {
        instance = this
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        if (prefs.getBoolean("overlay", false)) showPanel()
        h.removeCallbacks(tick); h.post(tick)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean { instance = null; hidePanel(); return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; h.removeCallbacks(tick); hidePanel(); super.onDestroy() }

    // ---------- main logic ----------
    private fun norm(s: CharSequence?): String =
        Normalizer.normalize((s ?: "").toString(), Normalizer.Form.NFD).replace("\u093C", "").trim().lowercase()

    private fun labelOf(n: AccessibilityNodeInfo): String {
        val t = n.text
        return if (!t.isNullOrEmpty()) norm(t) else norm(n.contentDescription)
    }

    private fun walk(n: AccessibilityNodeInfo?, f: (AccessibilityNodeInfo) -> Unit) {
        if (n == null) return
        f(n)
        for (i in 0 until n.childCount) walk(n.getChild(i), f)
    }

    private fun panelRect(): Rect? {
        val p = panel ?: return null
        val loc = IntArray(2); p.getLocationOnScreen(loc)
        val pad = (8 * resources.displayMetrics.density).toInt()
        return Rect(loc[0] - pad, loc[1] - pad, loc[0] + p.width + pad, loc[1] + p.height + pad)
    }

    private fun step(): Long {
        val root = rootInActiveWindow
        if (root == null || root.packageName?.toString() != "com.instagram.android") { setStatus("Instagram kholo"); return 1500L }
        val dm = resources.displayMetrics
        val sw = dm.widthPixels
        val sh = dm.heightPixels
        var confirm: AccessibilityNodeInfo? = null
        var scroller: AccessibilityNodeInfo? = null
        var best = 0
        val buttons = ArrayList<AccessibilityNodeInfo>()   // "Message" / "Following" buttons (har row ka)
        val dots = ArrayList<AccessibilityNodeInfo>()      // 3-dot (⋮) buttons
        val r = Rect()
        walk(root) { n ->
            val l = labelOf(n)
            n.getBoundsInScreen(r)
            if (l in unfollowLabels) {
                val cur = confirm
                if (cur == null || (!cur.isClickable && n.isClickable)) confirm = n
            } else if (l in followingLabels || l in messageLabels) {
                if (r.top > sh * 0.18 && r.centerX() > sw * 0.4 && r.centerX() < sw * 0.9) buttons.add(n)
            } else if (l in dotsLabels) {
                if (r.top > sh * 0.18 && r.bottom < sh * 0.97 && r.centerX() > sw * 0.8) dots.add(n)
            }
            if (n.isScrollable && r.height() > best) { best = r.height(); scroller = n }
        }
        val now = System.currentTimeMillis()

        // 1) Unfollow option / confirm (3-dot menu ya dialog me)
        val c = confirm
        if (c != null) {
            tap(c)
            if (pending) {
                count++; pending = false
                prefs.edit().putInt("total", prefs.getInt("total", 0) + 1).apply()
            }
            awaitSheet = false; tapCount.clear(); scrollFails = 0
            setStatus("Unfollow ✔"); return pause(1300L)
        }

        // 2) 3-dot menu abhi khul raha hai — thoda ruko
        if (awaitSheet) {
            if (now - awaitSince < 3500L) { setStatus("Menu wait…"); return 500L }
            awaitSheet = false; pending = false
        }

        // 3) Jis row me abhi bhi "Message"/"Following" hai wahi follow hai -> uska ⋮ dabao
        val rowKeys = HashSet<Int>()
        for (b in buttons) { b.getBoundsInScreen(r); rowKeys.add(r.centerY() / (sh / 25)) }
        val looksLikeList = rowKeys.size >= 2 || dots.isNotEmpty()
        if (looksLikeList) {
            buttons.sortBy { n -> val t = Rect(); n.getBoundsInScreen(t); t.top }
            val panelR = panelRect()
            for (b in buttons) {
                b.getBoundsInScreen(r)
                val k = r.flattenToString()
                val t = tapCount[k] ?: 0
                val cy = r.centerY()
                if (labelOf(b) in followingLabels) {
                    // purana tareeka: seedha Following button
                    if (t < 3) {
                        tapCount[k] = t + 1; tap(b)
                        pending = true; awaitSheet = true; awaitSince = now
                        setStatus("Button dabaya"); return pause(900L)
                    }
                    continue
                }
                if (t >= 2) continue
                // is row ka 3-dot button
                var dn: AccessibilityNodeInfo? = null
                var dd = Int.MAX_VALUE
                val tmp = Rect()
                for (d in dots) {
                    d.getBoundsInScreen(tmp)
                    val diff = abs(tmp.centerY() - cy)
                    if (diff < sh * 0.04 && diff < dd) { dd = diff; dn = d }
                }
                if (dn != null) {
                    tapCount[k] = t + 1; tap(dn)
                } else {
                    val x = sw * 0.945f
                    if (panelR != null && panelR.contains(x.toInt(), cy)) continue   // popup ke neeche hai
                    tapCount[k] = t + 1
                    gesture(x, cy.toFloat(), x, cy.toFloat(), 60)
                }
                pending = true; awaitSheet = true; awaitSince = now
                setStatus("⋮ dabaya"); return pause(900L)
            }
        }

        // 4) Scroll
        val sc = scroller
        val ok = if (sc != null) sc.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
                 else { gesture(sw / 2f, sh * 0.75f, sw / 2f, sh * 0.35f, 400); true }
        tapCount.clear()
        if (ok) { scrollFails = 0; setStatus("Scroll ↓") }
        else if (++scrollFails >= 3) { toggle(); setStatus("List khatam ✔") }
        return pause(1500L)
    }

    private fun tap(node: AccessibilityNodeInfo) {
        var n: AccessibilityNodeInfo? = node
        while (n != null && !n.isClickable) n = n.parent
        if (n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return
        val r = Rect(); node.getBoundsInScreen(r)
        gesture(r.centerX().toFloat(), r.centerY().toFloat(), r.centerX().toFloat(), r.centerY().toFloat(), 60)
    }

    private fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long) {
        val p = Path(); p.moveTo(x1, y1)
        if (x1 != x2 || y1 != y2) p.lineTo(x2, y2)
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build(), null, null)
    }

    // ---------- floating popup ----------
    private fun toggle() {
        running = !running; scrollFails = 0; pending = false; awaitSheet = false; tapCount.clear()
        if (running) { h.removeCallbacks(tick); h.post(tick) }
        icon?.text = if (running) "⏸" else "▶"
        setStatus(if (running) "Chal raha hai…" else "Pause")
    }

    private fun setStatus(s: String) { statusTv?.text = s; countTv?.text = "$count unfollow" }

    private fun showPanel() {
        if (panel != null) return
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#8E2DE2"), Color.parseColor("#F5576C"), Color.parseColor("#FFA630"))
            ).apply { cornerRadius = dp(22).toFloat() }
        }
        icon = TextView(this).apply { text = "▶"; textSize = 36f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        countTv = TextView(this).apply { text = "0 unfollow"; textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setTypeface(null, android.graphics.Typeface.BOLD) }
        statusTv = TextView(this).apply { text = "Pause"; textSize = 11f; setTextColor(Color.parseColor("#FFF1E0")); gravity = Gravity.CENTER }
        p.addView(icon); p.addView(countTv); p.addView(statusTv)

        val lp = WindowManager.LayoutParams(
            dp(120), dp(120), WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(16); lp.y = dp(220)

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        p.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) { lp.x = ox + dx; lp.y = oy + dy; wm.updateViewLayout(p, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) toggle()
            }
            true
        }
        wm.addView(p, lp)
        panel = p
        running = false
    }

    private fun hidePanel() {
        panel?.let { try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {} }
        panel = null; running = false
    }
}
