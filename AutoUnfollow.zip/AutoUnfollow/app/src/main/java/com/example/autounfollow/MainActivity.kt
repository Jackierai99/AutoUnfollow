package com.example.autounfollow

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }

        val info = TextView(this).apply {
            text = "1) Accessibility me 'Auto Unfollow' ON karo\n" +
                   "2) Instagram ko English me rakho\n" +
                   "3) Instagram > Profile > Following list kholo\n" +
                   "4) Yaha Start dabao, phir Instagram pe wapas jao"
            textSize = 15f
        }
        val limit = EditText(this).apply {
            hint = "Daily limit"; setText(p.getInt("limit", 60).toString())
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        val acc = Button(this).apply { text = "Accessibility settings kholo"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }
        val toggle = Button(this)
        fun refresh() { toggle.text = if (p.getBoolean("running", false)) "STOP" else "START" }
        toggle.setOnClickListener {
            val run = !p.getBoolean("running", false)
            p.edit().putInt("limit", limit.text.toString().toIntOrNull() ?: 60).putBoolean("running", run).apply()
            refresh()
            if (run) packageManager.getLaunchIntentForPackage("com.instagram.android")?.let { startActivity(it) }
        }
        refresh()
        val lp = ViewGroup.LayoutParams.MATCH_PARENT
        listOf(info, limit, acc, toggle).forEach { root.addView(it, LinearLayout.LayoutParams(lp, ViewGroup.LayoutParams.WRAP_CONTENT)) }
        setContentView(root)
    }

}
