package com.example.autounfollow

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.*

class MainActivity : Activity() {
    private lateinit var statusTv: TextView
    private lateinit var subTv: TextView
    private lateinit var totalTv: TextView
    private lateinit var toggle: Switch
    private lateinit var prefs: android.content.SharedPreferences
    private val chips = ArrayList<TextView>()
    private val h = Handler(Looper.getMainLooper())
    private var syncing = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(c1: String, c2: String = c1, r: Int = 16) =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.parseColor(c1), Color.parseColor(c2)))
            .apply { cornerRadius = dp(r).toFloat() }
    private fun txt(t: String, size: Float, color: String, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.parseColor(color)); if (bold) setTypeface(null, Typeface.BOLD)
    }
    private fun btn(t: String, c1: String, c2: String, click: () -> Unit) = TextView(this).apply {
        text = t; textSize = 17f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD); gravity = Gravity.CENTER
        background = bg(c1, c2, 16); setPadding(dp(16), dp(16), dp(16), dp(16)); setOnClickListener { click() }
    }
    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = bg("#16162B", "#16162B", 16); setPadding(dp(16), dp(14), dp(16), dp(14))
    }
    private fun lp(top: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top) }

    private fun serviceOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains("UnfollowService") && s.contains(packageName)
    }

    // ---- Accessibility ON/OFF ----
    // Seedha ON/OFF tabhi ho sakta hai jab WRITE_SECURE_SETTINGS mili ho (adb se ek baar).
    private fun setViaSecure(enable: Boolean): Boolean = try {
        val cn = ComponentName(this, UnfollowService::class.java)
        val full = cn.flattenToString(); val short = cn.flattenToShortString()
        val cur = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        val list = cur.split(":").filter { it.isNotEmpty() && it != full && it != short }.toMutableList()
        if (enable) list.add(full)
        Settings.Secure.putString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, list.joinToString(":"))
        if (enable) Settings.Secure.putString(contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, "1")
        true
    } catch (e: SecurityException) { false }

    private fun onToggle(checked: Boolean) {
        if (checked) {
            if (setViaSecure(true)) {
                Toast.makeText(this, "Service ON ✅", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Auto Unfollow चुनकर ON कर दो", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        } else {
            val svc = UnfollowService.instance
            if (svc != null) { svc.disableSelf(); Toast.makeText(this, "Service OFF", Toast.LENGTH_SHORT).show() }
            else if (!setViaSecure(false)) startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        refresh(); h.postDelayed({ refresh() }, 700); h.postDelayed({ refresh() }, 1500)
    }

    private fun refresh() {
        val on = serviceOn()
        syncing = true; toggle.isChecked = on; syncing = false
        statusTv.text = if (on) "Accessibility  ON" else "Accessibility  OFF"
        statusTv.setTextColor(Color.parseColor(if (on) "#5CFF9D" else "#FF6B6B"))
        subTv.text = if (on) "सब तैयार है — START दबाओ" else "स्विच ON करो और Auto Unfollow चुनो"
        totalTv.text = prefs.getInt("total", 0).toString()
        val sp = prefs.getInt("speed", 1)
        chips.forEachIndexed { i, c ->
            c.background = if (i == sp) bg("#8E2DE2", "#F5576C", 12) else bg("#23233D", "#23233D", 12)
            c.setTextColor(Color.parseColor(if (i == sp) "#FFFFFF" else "#9A9AB8"))
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), dp(40), dp(22), dp(30))
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.logo)
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) }
            }
        }
        col.addView(logo, LinearLayout.LayoutParams(dp(150), dp(150)))
        col.addView(txt("AUTO UNFOLLOW", 26f, "#FFFFFF", true).apply { gravity = Gravity.CENTER }, lp(14))
        col.addView(txt("Instagram की बढ़ी हुई Following list को अपने आप साफ़ करो", 14f, "#A9A9C8").apply { gravity = Gravity.CENTER }, lp(4))

        // --- Accessibility toggle card ---
        val tc = card().apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val tl = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        statusTv = txt("", 17f, "#FFFFFF", true)
        subTv = txt("", 12f, "#A9A9C8")
        tl.addView(statusTv); tl.addView(subTv)
        tc.addView(tl, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        toggle = Switch(this).apply {
            val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            thumbTintList = ColorStateList(states, intArrayOf(Color.parseColor("#5CFF9D"), Color.parseColor("#9A9AB8")))
            trackTintList = ColorStateList(states, intArrayOf(Color.parseColor("#2E7D55"), Color.parseColor("#3A3A55")))
            scaleX = 1.3f; scaleY = 1.3f
            setOnCheckedChangeListener { _, checked -> if (!syncing) onToggle(checked) }
        }
        tc.addView(toggle)
        col.addView(tc, lp(22))

        // --- Stats card ---
        val sc = card().apply { gravity = Gravity.CENTER_HORIZONTAL }
        totalTv = txt("0", 34f, "#FFA630", true).apply { gravity = Gravity.CENTER }
        sc.addView(totalTv)
        sc.addView(txt("कुल Unfollow हो चुके", 13f, "#A9A9C8").apply { gravity = Gravity.CENTER })
        col.addView(sc, lp(12))

        // --- Speed card ---
        val spc = card()
        spc.addView(txt("स्पीड", 14f, "#FFFFFF", true))
        spc.addView(txt("बहुत तेज़ चलाने पर Instagram कुछ देर के लिए रोक (action block) लगा सकता है।", 11f, "#8888A8"), lp(2))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("🐢 धीमा", "⚡ नॉर्मल", "🚀 तेज़").forEachIndexed { i, name ->
            val c = TextView(this).apply {
                text = name; textSize = 14f; gravity = Gravity.CENTER; setTypeface(null, Typeface.BOLD)
                setPadding(dp(4), dp(11), dp(4), dp(11))
                setOnClickListener { prefs.edit().putInt("speed", i).apply(); refresh() }
            }
            chips.add(c)
            row.addView(c, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (i > 0) leftMargin = dp(8)
            })
        }
        spc.addView(row, lp(10))
        col.addView(spc, lp(12))

        // --- Steps ---
        col.addView(txt(
            "कैसे चलाएँ\n\n" +
            "1️⃣  ऊपर Accessibility का स्विच ON करो (Auto Unfollow चुनो)\n" +
            "2️⃣  'START' दबाओ — Instagram अपने आप खुलेगा → Profile → Following list खुलेगी\n" +
            "3️⃣  फिर अपने आप हर आदमी के ⋮ पर क्लिक → Unfollow → scroll चलता रहेगा\n" +
            "4️⃣  रील या किसी और स्क्रीन पर चला जाए, या Instagram से बाहर निकल जाए, तो खुद वापस Following list पर आ जाएगा। ⏸ दबाओ → रुक जाएगा\n\n" +
            "पॉपअप को उँगली से कहीं भी खिसका सकते हो।\n" +
            "⚠️ Instagram की भाषा English रखो।", 14f, "#D8D8F0"
        ).apply { background = bg("#16162B", "#16162B", 14); setPadding(dp(16), dp(16), dp(16), dp(16)) }, lp(12))

        col.addView(btn("▶  START  (Instagram खोलो)", "#F5576C", "#FFA630") {
            if (!serviceOn()) {
                Toast.makeText(this, "पहले ऊपर Accessibility ON करो", Toast.LENGTH_LONG).show()
            } else {
                prefs.edit().putBoolean("overlay", false).commit()
                prefs.edit().putBoolean("overlay", true).commit()
                prefs.edit().putLong("go", System.currentTimeMillis()).commit()   // service ko auto-start ka signal
                val i = packageManager.getLaunchIntentForPackage("com.instagram.android")
                if (i != null) startActivity(i) else Toast.makeText(this, "Instagram install नहीं है", Toast.LENGTH_LONG).show()
            }
        }, lp(18))
        col.addView(btn("✖  पॉपअप बंद करो", "#2A2A44", "#2A2A44") {
            prefs.edit().putBoolean("overlay", false).commit()
        }, lp(12))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#06060F")); isFillViewport = true; addView(col)
        })
        refresh()
    }

    override fun onResume() { super.onResume(); refresh() }
}
