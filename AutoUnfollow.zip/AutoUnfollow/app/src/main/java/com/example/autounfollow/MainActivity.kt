package com.example.autounfollow

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.*

class MainActivity : Activity() {
    private lateinit var statusTv: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(c1: String, c2: String = c1, r: Int = 16) =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.parseColor(c1), Color.parseColor(c2)))
            .apply { cornerRadius = dp(r).toFloat() }
    private fun txt(t: String, size: Float, color: String, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.parseColor(color)); if (bold) setTypeface(null, Typeface.BOLD)
    }
    private fun btn(t: String, c1: String, c2: String, click: () -> Unit) = TextView(this).apply {
        text = t; textSize = 17f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD); gravity = Gravity.CENTER
        background = bg(c1, c2, 16); setPadding(dp(16), dp(16), dp(16), dp(16)); setOnClickListener { click() }
    }
    private fun lp(top: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top) }

    private fun serviceOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains("UnfollowService") && s.contains(packageName)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), dp(40), dp(22), dp(30))
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.logo)
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) }
            }
        }
        col.addView(logo, LinearLayout.LayoutParams(dp(170), dp(170)))
        col.addView(txt("AUTO UNFOLLOW", 26f, "#FFFFFF", true).apply { gravity = Gravity.CENTER }, lp(14))
        col.addView(txt("Instagram की बढ़ी हुई Following list को अपने आप साफ़ करो", 14f, "#A9A9C8").apply { gravity = Gravity.CENTER }, lp(4))

        statusTv = txt("", 15f, "#FFFFFF", true).apply {
            gravity = Gravity.CENTER; background = bg("#16162B", "#16162B", 14); setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        col.addView(statusTv, lp(22))

        col.addView(txt(
            "कैसे चलाएँ\n\n" +
            "1️⃣  नीचे 'Accessibility ON करो' दबाओ और Auto Unfollow को ON करो\n" +
            "2️⃣  'START' दबाओ — Instagram खुलेगा और स्क्रीन पर रंगीन पॉपअप आएगा\n" +
            "3️⃣  Instagram में Profile → Following list खोलो\n" +
            "4️⃣  पॉपअप का ▶ दबाओ → अपने आप unfollow शुरू। ⏸ दबाओ → रुक जाएगा\n\n" +
            "पॉपअप को उँगली से कहीं भी खिसका सकते हो।\n" +
            "⚠️ Instagram की भाषा English रखो।", 14f, "#D8D8F0"
        ).apply { background = bg("#16162B", "#16162B", 14); setPadding(dp(16), dp(16), dp(16), dp(16)) }, lp(14))

        col.addView(btn("▶  START  (Instagram खोलो)", "#F5576C", "#FFA630") {
            if (!serviceOn()) {
                Toast.makeText(this, "पहले Accessibility में Auto Unfollow ON करो", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } else {
                p.edit().putBoolean("overlay", false).commit()
                p.edit().putBoolean("overlay", true).commit()
                val i = packageManager.getLaunchIntentForPackage("com.instagram.android")
                if (i != null) startActivity(i) else Toast.makeText(this, "Instagram install नहीं है", Toast.LENGTH_LONG).show()
            }
        }, lp(22))
        col.addView(btn("⚙  Accessibility ON करो", "#8E2DE2", "#4A00E0") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, lp(12))
        col.addView(btn("✖  पॉपअप बंद करो", "#2A2A44", "#2A2A44") {
            p.edit().putBoolean("overlay", false).commit()
        }, lp(12))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#06060F")); isFillViewport = true; addView(col)
        })
    }

    override fun onResume() {
        super.onResume()
        val on = serviceOn()
        statusTv.text = if (on) "✅  Service ON — सब तैयार है" else "❌  Service OFF — Accessibility में ON करो"
        statusTv.setTextColor(Color.parseColor(if (on) "#5CFF9D" else "#FF6B6B"))
    }
}
